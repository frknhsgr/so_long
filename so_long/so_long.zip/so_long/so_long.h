/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fhosgor <fhosgor@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/08 16:03:41 by fhosgor           #+#    #+#             */
/*   Updated: 2024/01/12 16:05:12 by fhosgor          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H

# include "get_next_line/get_next_line.h"
# include "ft_printf/ft_printf.h"
# include "mlx/mlx.h"
# include <fcntl.h>

typedef struct s_map
{
	char	**map;
	char	**map_copy;
	void	*mlx;
	void	*win;
	void	*player;
	void	*coin;
	void	*ground;
	void	*exit;
	void	*wall;
	int		mapx;
	int		mapy;
	int		player_x;
	int		player_y;
	int		p_count;
	int		c_count;
	int		e_count;
}	t_map;
void	map_len(t_map *solong, char *mapname);
void	get_map(t_map *solong, char *mapname);
void	get_map_copy(t_map *solong, char *mapname);

void	map_checker(t_map *solong);
void	check_mapname(char *str);
void	count_objects(t_map *solong);
void	check_objects(t_map *solong);
void	ft_error(t_map *solong);
void	fill(t_map *solong, int x, int y);
void	flood_fill(t_map *solong);

void	assigment(t_map *solong);
void	print_map1(t_map *solong);
void	print_map2(t_map *solong, char c, int x, int y);

int		main(int ac, char **av);

#endif