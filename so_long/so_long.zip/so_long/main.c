/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fhosgor <fhosgor@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/09 17:34:19 by fhosgor           #+#    #+#             */
/*   Updated: 2024/01/12 16:27:48 by fhosgor          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	main(int ac, char **av)
{
	t_map	solong;

	if (ac != 2)
		return (0);
	check_mapname(av[1]);
	get_map(&solong, av[1]);
	map_checker(&solong);
	check_objects(&solong);
	flood_fill(&solong);
	solong.mlx = mlx_init();
	solong.win = mlx_new_window(solong.mlx, solong.mapx * 64, \
	solong.mapy * 64, "so_long");
	assigment(&solong);
	print_map1(&solong);
	mlx_loop(solong.mlx);
}
